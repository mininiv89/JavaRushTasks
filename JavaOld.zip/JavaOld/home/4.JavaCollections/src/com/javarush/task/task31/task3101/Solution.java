package com.javarush.task.task31.task3101;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/*
Проход по дереву файлов
*/
public class Solution {
    public static void main(String[] args) {
        String path = args[0];
        String resultFileAbsolutePath = args[1];

        File folder = new File(path);
        File directory = new File(resultFileAbsolutePath);
        File result = new File(directory.getParent() + "/allFilesContent.txt");
        System.out.println(result.getAbsolutePath());
        directory.renameTo(result);

        Queue<File> queue = new PriorityQueue<>();
        Collections.addAll(queue, folder.listFiles());

        for (File file : queue) {
//            File currentFile = file
        }

        try (FileWriter write = new FileWriter(result)) {

        }
        catch (IOException e) {
            e.printStackTrace();
        }


    }

    public static void deleteFile(File file) {
        if (!file.delete()) System.out.println("Can not delete file with name " + file.getName());
    }
}
