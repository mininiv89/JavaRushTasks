package com.javarush.task.task09.task0918;

/* 
Все свои, даже исключения
*/

public class Solution {
    public static void main(String[] args) {
    }
    
    static class MyException {
    }

    static class MyException2 {
    }

    static class MyException3 {
    }

    static class MyException4 {
    }
}

