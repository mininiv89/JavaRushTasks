package com.javarush.task.task05.task0506;

/* 
Человечки
*/

public class Person {
    //напишите тут ваш код
    private String name;
    private int age;
    private String address;
    private char sex;

    public static void main(String[] args) {

        }

    }


