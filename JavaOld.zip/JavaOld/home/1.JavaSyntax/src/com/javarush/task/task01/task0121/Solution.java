package com.javarush.task.task01.task0121;

/* 
Контракт
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        System.out.println("Меня зовут Амиго.");
        System.out.println();
        System.out.println("Я согласен на зарплату $800/месяц в первый год.");
        System.out.println("Я согласен на зарплату $1500/месяц во второй год.");
        System.out.println("Я согласен на зарплату $2200/месяц в третий год.");
        System.out.println("Я согласен на зарплату $2700/месяц в четвертый год.");
        System.out.println("Я согласен на зарплату $3200/месяц в пятый год.");
        System.out.println();
        System.out.println("Поцелуй мой блестящий металлический зад!");










    }
}
