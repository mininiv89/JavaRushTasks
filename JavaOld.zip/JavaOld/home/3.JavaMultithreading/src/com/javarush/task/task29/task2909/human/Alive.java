package com.javarush.task.task29.task2909.human;

/**
 * Created by igor on 01.06.17.
 */
public interface Alive {
	void live();
}
