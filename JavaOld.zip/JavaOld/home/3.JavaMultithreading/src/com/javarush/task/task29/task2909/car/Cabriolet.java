package com.javarush.task.task29.task2909.car;

/**
 * Created by igor on 03.06.17.
 */
public class Cabriolet extends Car {

	public Cabriolet(int numberOfPassengers) {
		super(Car.CABRIOLET, numberOfPassengers);
	}

	@Override
	public int getMaxSpeed() {
		return MAX_CABRIOLET_SPEED;
	}
}
