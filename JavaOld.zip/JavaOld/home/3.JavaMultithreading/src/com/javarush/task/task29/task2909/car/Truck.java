package com.javarush.task.task29.task2909.car;

/**
 * Created by igor on 03.06.17.
 */
public class Truck extends Car {

	public Truck(int numberOfPassengers) {
		super(Car.TRUCK, numberOfPassengers);
	}

	@Override
	public int getMaxSpeed() {
		return MAX_TRUCK_SPEED;
	}
}
