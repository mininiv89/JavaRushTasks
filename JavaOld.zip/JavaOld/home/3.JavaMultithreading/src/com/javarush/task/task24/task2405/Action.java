package com.javarush.task.task24.task2405;

public interface Action {
    void someAction();
}
