package com.javarush.task.task20.task2027;

import java.util.ArrayList;
import java.util.List;

/* 
Кроссворд
*/
public class Solution {
    public static void main(String[] args) {
        int[][] crossword = new int[][]{
                {'f', 'd', 'e', 'r', 'l', 'k'},
                {'u', 's', 'a', 'm', 'e', 'o'},
                {'l', 'n', 'g', 'r', 'o', 'v'},
                {'m', 'l', 'p', 'r', 'r', 'h'},
                {'p', 'o', 'e', 'e', 'j', 'j'}
        };
        List<Word> list = detectAllWords(crossword, "home", "same");

        for (Word words : list)
            System.out.println(words.toString());
        /*
Ожидаемый результат
home - (5, 3) - (2, 0)
same - (1, 1) - (4, 1)
         */
    }

    public static List<Word> detectAllWords(int[][] crossword, String... words) {
        List<Word> list = new ArrayList<>();

        for (String word : words) {

            char[] chars = word.toCharArray();
            int lengthWord = chars.length - 1;

            //Предполагаемые координаты первой буквы
            int x1 = 0;
            int y1 = 0;

            //Предполагаемые координаты последней буквы
            int x2 = 0;
            int y2;

            int n1;
            int n2;

            search:
            for (int[] arr : crossword) {
                for (int posX1 = 0; posX1 < arr.length; posX1++) {

                    n1 = searchInArr(arr, posX1, chars[0]);

                    if (n1 != -1) {
                        x1 = n1;
                        posX1 = n1;
                        //Поиск последней буквы
                        y2 = 0;
                        for (int[] arrTwo : crossword) {
                            for (int posX2 = 0; posX2 < arr.length; posX2++) {

                                n2 = searchInArr(arrTwo, posX2, chars[chars.length - 1]);

                                if (n2 != -1) {
                                    x2 = n2;
                                    posX2 = n2;
                                }

                                research:
                                if (Math.abs(x2 - x1) == lengthWord || Math.abs(y2 - y1) == lengthWord) {

                                    if (testWord(crossword,x1,y1,x2,y2,chars))
                                        break research;

                                    Word foundWord = new Word(word);
                                    foundWord.setStartPoint(x1, y1);
                                    foundWord.setEndPoint(x2, y2);
                                    list.add(foundWord);
                                    break search;
                                }
                            }
                            y2++;
                        }
                    }
                }
                y1++;
            }


        }

        return list;
    }
    // Поиск позиции в массиве
    private static int searchInArr(int[] arr, int position, char charWord) {
        int found = -1;
        for (int i = position; i < arr.length; i++) {
            if (arr[i] == charWord) {
                found = i;
                break;
            }
        }
        return found;
    }

    //Проверка слова
    private static boolean testWord(int[][] crossword, int x1, int y1, int x2, int y2, char[] charWord) {
        for (char chars : charWord) {
            if (x1 == x2) {
                if (y1 < y2)
                    for (int i = y1; i <= y2; i++)
                        return crossword[x1][i] == chars ? true : false;
                if (y1 > y2)
                    for (int i = y1; i >= y2; i--)
                        return crossword[x1][i] == chars ? true : false;
            } else if (y1 == y2) {
                if (x1 < x2)
                    for (int i = x1; i <= x2; i++)
                        return crossword[i][y1] == chars ? true : false;
                if (x1 > x2)
                    for (int i = x1; i >= x2; i--)
                        return crossword[i][y1] == chars ? true : false;
            } else {




            }
        }
        return false;
    }

    public static class Word {
        private String text;
        private int startX;
        private int startY;
        private int endX;
        private int endY;

        public Word(String text) {
            this.text = text;
        }

        public void setStartPoint(int i, int j) {
            startX = i;
            startY = j;
        }

        public void setEndPoint(int i, int j) {
            endX = i;
            endY = j;
        }

        @Override
        public String toString() {
            return String.format("%s - (%d, %d) - (%d, %d)", text, startX, startY, endX, endY);
        }
    }
}
