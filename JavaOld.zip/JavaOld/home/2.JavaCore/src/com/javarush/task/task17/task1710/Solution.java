//package com.javarush.task.task17.task1710;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.regex.Pattern;
//
///*
//CRUD
//*/
//
//public class Solution {
//    public static List<Person> allPeople = new ArrayList<Person>();
//
//    static {
//        allPeople.add(Person.createMale("Иванов Иван", new Date()));  //сегодня родился    id=0
//        allPeople.add(Person.createMale("Петров Петр", new Date()));  //сегодня родился    id=1
//    }
//
//    public static void main(String[] args) throws IOException {
//        //start here - начни тут
//        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//        String command;
//
//
//        while (true) {
//            command = reader.readLine();
//            if (command.equals("end")) break;
//            String[] string = command.split(" ");
//            new Commands(string);
//        }
//        reader.close();
//    }
//
//    public static class Commands {
//        private String[] strings;
//        private String name;
//        private Sex sex;
//        private Date date;
//        private int id;
//        private Person person;
//
//        public Commands(String[] strings) {
//            this.strings = strings;
//
//            this.name = strings[1];
//
//            if (strings[2].equals("м")) this.sex = Sex.MALE;
//            else if (strings[2].equals("ж")) this.sex = Sex.FEMALE;
//            else {
//                System.out.println("Пол не задан!");
//                this.sex = null;
//            }
//
//            if (s)
//
//
//            this.date = new Date(strings[3]);
//
//
//            if (strings[0].equals("-c")) create();
//            else if (strings[0].equals("-u")) update();
//            else if (strings[0].equals("-d")) delete();
//            else if (strings[0].equals("-i")) show();
//            else System.out.println("Команда не найдена: начинать вводить -c, -u, -d, -i");
//
//        }
//
//        private void create() {
//            System.out.println("\n ---- Создание позиции ---- \n");
//
//            if (sex == Sex.MALE) person.createMale(name, date);
//            else person.createFemale(name, date);
//
//            System.out.println("\n -------------------------- \n");
//        }
//
//        private  void update() {
//            System.out.println("\n ---- Обновление позиции ---- \n");
//            Person personOld = allPeople[id];
//            personOld.setName(name);
//            personOld.setSex(sex);
//            personOld.setBirthDay(date);
//
//            System.out.println("\n ---------------------------- \n");
//        }
//
//        private void delete() {
//            System.out.println("\n ---- Удаление позиции ---- \n");
//
//
//
//            System.out.println("\n -------------------------- \n");
//        }
//
//        private void show() {
//            System.out.println("\n ---- Показ списка ---- \n");
//
//
//
//            System.out.println("\n ---------------------- \n");
//        }
//    }
//}
