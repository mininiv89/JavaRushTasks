package com.javarush.task.task16.task1631.common;

/**
 * Created by igor on 04.03.17.
 */
public class BmpReader implements ImageReader {
	public BmpReader() {
	}
}
