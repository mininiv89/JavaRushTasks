package com.javarush.task.task19.task1918;

/* 
Знакомство с тегами
*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Solution {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
             FileReader file = new FileReader("/Users/igor/Documents/JavaRushHomeWork/JavaRushTasks/2.JavaCore/src/com/javarush/task/task19/task1918/index.html")
        ) {
            String tag = args[0];
            Pattern p;
            Matcher m;
            StringBuilder text = new StringBuilder();
            int countInFileRead;
            char[] buffer = new char[1024];

            while (file.ready()) {
                countInFileRead = file.read(buffer);
                text.append(buffer, 0, countInFileRead);
            }

            System.out.println(text.toString());
            p = Pattern.compile("(<" + tag + ").+(</" + tag + ">)");
            m = p.matcher(text);


        }
        catch (IOException e) {
            e.printStackTrace();
        }

        for (String string : list) {
            System.out.println(string);
        }

    }
}
