package com.javarush.task.task15.task1525;

public class Statics {
    public static String FILE_NAME = "/Users/igor/Documents/JavaRushHomeWork/JavaRushTasks/2.JavaCore/src/com/javarush/task/task15/task1525/file1.txt" ;
}
