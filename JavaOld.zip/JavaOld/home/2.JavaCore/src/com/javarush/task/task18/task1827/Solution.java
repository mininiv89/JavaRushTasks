package com.javarush.task.task18.task1827;

/* 
Прайсы
*/

public class Solution {
    public static void main(String[] args) throws Exception {
    }
}
