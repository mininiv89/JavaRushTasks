package com.javarush.task.task23.task2312;


public enum SnakeDirection {
    UP,
    RIGHT,
    DOWN,
    LEFT
}
