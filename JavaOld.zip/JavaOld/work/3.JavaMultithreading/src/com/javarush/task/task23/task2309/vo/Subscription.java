package com.javarush.task.task23.task2309.vo;

/**
 * Created by i.minin on 16.05.2017.
 */
public class Subscription extends NamedItem  {
}
