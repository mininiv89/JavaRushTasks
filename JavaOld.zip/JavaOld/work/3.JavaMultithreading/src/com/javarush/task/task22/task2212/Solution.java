package com.javarush.task.task22.task2212;

import java.util.regex.Pattern;
/*
Проверка номера телефона
*/
public class Solution {
    public static boolean checkTelNumber(String telNumber) {
        String p = "";
        return false;
    }

    public static void main(String[] args) {

    }
}
