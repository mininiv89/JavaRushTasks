package com.javarush.task.task24.task2401;

/**
 * Created by i.minin on 17.05.2017.
 */
public interface SelfInterfaceMarker {
}
