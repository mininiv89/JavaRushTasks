package com.javarush.task.task22.task2210;

/* 
StringTokenizer
*/
public class Solution {
    public static void main(String[] args) {

    }
    public static String [] getTokens(String query, String delimiter) {
        return null;
    }
}
