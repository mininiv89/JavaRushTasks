package com.javarush.task.task19.task1918;

/* 
Знакомство с тегами
*/

public class Solution {
    public static void main(String[] args) {
    }
}
