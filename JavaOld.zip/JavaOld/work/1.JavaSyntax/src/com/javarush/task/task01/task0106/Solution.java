package com.javarush.task.task01.task0106;

/* 
Баги и фичи
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        System.out.println("Это не баг, это фича.");
    }
}
